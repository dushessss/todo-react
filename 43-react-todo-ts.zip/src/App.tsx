import TaskList from "./components/TaskList.tsx";
import "./App.css"

const App = () => {
    return (
        <>
          <TaskList/>
        </>
    );
};

export default App;